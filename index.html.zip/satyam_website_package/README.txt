╔══════════════════════════════════════════════════════════╗
║  SATYAM PROPERTY CONSULTANCY — WEBSITE PACKAGE           ║
╚══════════════════════════════════════════════════════════╝

📁 FILES IN THIS ZIP
────────────────────
• index.html  — Complete website (single file, ready to use)
• README.txt  — This file

🔐 ADMIN LOGIN
──────────────
• Username: admin
• Password: satyam123
• Click the ⚙️ gear icon at bottom-right of any page to login

📱 HOW TO USE
─────────────
Option 1 — Local Testing:
  Just double-click index.html to open in your browser.

Option 2 — Host on Vercel:
  1. Go to https://vercel.com/new/clone/drop
  2. Drag & drop index.html
  3. Click Deploy
  4. Live in 30 seconds

Option 3 — Host on GitHub Pages:
  1. Upload index.html to your GitHub repository
  2. Settings → Pages → Source: main branch → Save
  3. Live in 2 minutes

Option 4 — Host on Netlify:
  1. Go to https://app.netlify.com/drop
  2. Drag & drop index.html
  3. Live instantly

🔥 FIREBASE SETUP (Cross-device sync)
─────────────────────────────────────
Already configured for project: satyam-property
• Firestore Rules: Set to allow public read/write
• Data syncs automatically across all devices
• Works offline too (localStorage fallback)

📞 CONTACT DETAILS (Pre-filled in website)
───────────────────────────────────────────
• Phone/WhatsApp: +91 85119 70102
• Email: info@satyampropertyconsultancy.com
• Office: 505 & 506 Centrum Heights, Nava Vadaj, Ahmedabad

✨ FEATURES
───────────
• 9 pages: Home, About, Properties, Projects, Plans & EMI, 
  Contact, Terms, Privacy, Disclaimer
• Admin panel (add/edit/delete properties, projects, subscribers)
• User login/register system for subscribers  
• Subscriber dashboard with plan details
• EMI & Loan Eligibility calculators
• Property & Project detail modals with:
  - Facing direction, floors, furniture, nearby locations
  - 40+ amenities, specifications, RERA info
  - Brochure download, video tour, image gallery
  - Matching properties suggestions
• AI Chatbot + WhatsApp chat widget
• Property comparison tool
• Favorites system
• Cross-device data sync via Firebase
• Fully responsive (mobile, tablet, desktop)

🔧 MAKING CHANGES
─────────────────
All settings can be changed from the admin panel:
• Contact info (Settings tab)
• Plan prices (Manage Plans tab)  
• Properties (Add/Manage Properties)
• Projects (Add/Manage Projects)
• Subscribers (Subscribers tab)

No code editing required!

© 2025 Satyam Property Consultancy®
